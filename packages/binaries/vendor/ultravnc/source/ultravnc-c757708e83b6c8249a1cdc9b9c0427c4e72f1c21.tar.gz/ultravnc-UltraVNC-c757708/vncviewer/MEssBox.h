// This file is part of UltraVNC
// https://github.com/ultravnc/UltraVNC
// https://uvnc.com/
//
// SPDX-License-Identifier: GPL-3.0-or-later
//
// SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999 AT&T Laboratories Cambridge. All Rights Reserved.
//


// Display the about box!

void ShowMessageBox(char *info, int error_nr);
void ShowMessageBox(const wchar_t *info, int error_nr);
void ShowMessageBox2(char *info, int error_nr);
void ShowMessageBox2(const wchar_t *info, int error_nr);
