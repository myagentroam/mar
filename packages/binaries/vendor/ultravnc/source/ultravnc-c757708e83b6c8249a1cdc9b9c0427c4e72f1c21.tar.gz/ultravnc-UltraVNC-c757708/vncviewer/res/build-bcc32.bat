:: // This file is part of UltraVNC
:: // https://github.com/ultravnc/UltraVNC
:: // https://uvnc.com/
:: //
:: // SPDX-License-Identifier: GPL-3.0-or-later
:: //
:: // SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
:: // SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
:: //


@echo off
echo:>afxres.h
brc32.exe -r -fovncviewer.res vncviewer.rc
del afxres.h
