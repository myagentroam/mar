// This file is part of UltraVNC
// https://github.com/ultravnc/UltraVNC
// https://uvnc.com/
//
// SPDX-License-Identifier: GPL-3.0-or-later
//
// SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999 AT&T Laboratories Cambridge. All Rights Reserved.
//


/*
 *  Functions for VNC password management and authentication.
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <process.h>
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include "vncauth.h"
#include "../common/d3des.h"

unsigned char dynkey[8] = { 23,82,107,6,35,78,88,7 };
void vncSetDynKey(unsigned char key[8])
{
	dynkey[0] = key[0]; 
	dynkey[1] = key[1]; 
	dynkey[2] = key[2]; 
	dynkey[3] = key[3]; 
	dynkey[4] = key[4]; 
	dynkey[5] = key[5]; 
	dynkey[6] = key[6]; 
	dynkey[7] = key[7]; 
}
/*
*   We use a fixed key to store passwords, since we assume that our local
*   file system is secure but nonetheless don't want to store passwords
*   as plaintext.
*/
unsigned char fixedkey[8] = { 23,82,107,6,35,78,88,7 };


/*
 *   Encrypt a password and store it in a file.
 */
int
vncEncryptPasswd(char *passwd, char *encryptedPasswd, int secure)
{
    size_t i;

    /* pad password with nulls */

    for (i = 0; i < MAXPWLEN; i++) {
	if (i < strlen(passwd)) {
	    encryptedPasswd[i] = passwd[i];
	} else {
	    encryptedPasswd[i] = 0;
	}
    }

    /* Do encryption in-place - this way we overwrite our copy of the plaintext
       password */
	if (secure)
		 deskey(dynkey, EN0);
	else
		deskey(fixedkey, EN0);
    des((unsigned  char*) encryptedPasswd, (unsigned char*) encryptedPasswd);

    return 8;
}

/*
 *   Decrypt a password. Returns a pointer to a newly allocated
 *   string containing the password or a null pointer if the password could
 *   not be retrieved for some reason.
 */
char *
vncDecryptPasswd(char *inouttext, int secure)
{
    unsigned char *passwd = (unsigned char *)malloc(9);
	if (secure)
		deskey(dynkey, DE1);
	else
		deskey(fixedkey, DE1);
    des((unsigned char*) inouttext, passwd);

    passwd[8] = 0;

    return (char *)passwd;
}

/*
 *   Generate a set of random bytes for use in challenge-response authentication.
 */
/*
 *   Fill a buffer with cryptographically secure random bytes for use in
 *   challenge-response authentication. Falls back to the legacy provider
 *   if the system-preferred CNG RNG is unavailable.
 */
static int
vncSecureRandomBytes(unsigned char *where, unsigned long len) {
  if (BCryptGenRandom(NULL, where, len,
                      BCRYPT_USE_SYSTEM_PREFERRED_RNG) == 0)
    return 1;
  {
    HCRYPTPROV hProv;
    int ok = 0;
    if (CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL,
                            CRYPT_VERIFYCONTEXT)) {
      ok = CryptGenRandom(hProv, len, where) ? 1 : 0;
      CryptReleaseContext(hProv, 0);
    }
    return ok;
  }
}

void
vncRandomBytes(unsigned char *where) {
  if (!vncSecureRandomBytes(where, CHALLENGESIZE))
    memset(where, 0, CHALLENGESIZE);
}

void
vncRandomBytesMs(unsigned char *where) {
  if (!vncSecureRandomBytes(where, CHALLENGESIZEMS))
    memset(where, 0, CHALLENGESIZEMS);
}

/*
 *   Encrypt some bytes in memory using a password.
 */
void
vncEncryptBytes(unsigned char *where, const char *passwd)
{
    unsigned char key[8];
    size_t i;

    /* key is simply password padded with nulls */

    for (i = 0; i < 8; i++) {
	if (i < strlen(passwd)) {
	    key[i] = passwd[i];
	} else {
	    key[i] = 0;
	}
    }

    deskey(key, EN0);

    for (i = 0; i < CHALLENGESIZE; i += 8) {
	des(where+i, where+i);
    }
}

/*
 *   marscha@2006
 *   Decrypt bytes[length] in memory using key.
 *   Key has to be 8 bytes, length a multiple of 8 bytes.
 */
void
vncDecryptBytes(unsigned char *where, const int length, const unsigned char *key) {
	int i, j;
	deskey((unsigned char*) key, DE1);
	for (i = length - 8; i > 0; i -= 8) {
		des(where + i, where + i);
		for (j = 0; j < 8; j++)
			where[i + j] ^= where[i + j - 8];
	}
	/* i = 0 */
	des (where, where);
	for (i = 0; i < 8; i++)
		where[i] ^= key[i];
}
