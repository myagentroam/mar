// This file is part of UltraVNC
// https://github.com/ultravnc/UltraVNC
// https://uvnc.com/
//
// SPDX-License-Identifier: GPL-3.0-or-later
//
// SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
//


// For translating all messages
// find and translate all MessageBox                          -- done
// find and translate all MsgBox                              -- done
// find and translate all sendMessage with strings            -- done
// find and copy here and delete all messages string const    -- done
// find and translate all SetWindowText                       -- done
// find and translate all SetDlgItemText                      -- done

// All VNCLOG messages are NOT translated for now


#ifdef LOCALIZATION_MESSAGES

// LOCALIZATION_MESSAGES is only declare in winvnc.cpp

char sz_ID_FAILED_INIT[64];  //    "Failed to initialise the socket system"
char sz_ID_WINVNC_USAGE[64];  //   "UltraVNC Server Usage"
char sz_ID_ANOTHER_INST[64];  //   "Another instance of UltraVNC Server is already running"
char sz_ID_NO_EXIST_INST[64];  // "No existing instance of UltraVNC Server could be contacted"
char sz_ID_UNABLE_INST[64];  //    "Unable to install UltraVNC Server service"
char sz_ID_SCM_NOT_HERE[128];  // "The SCM could not be contacted - the UltraVNC Server service was not installed"
char sz_ID_SERV_NOT_REG[64];   // "The UltraVNC Server service could not be registered"
char sz_ID_SERV_FAIL_ST[64];  //   "The UltraVNC Server service failed to start"
char sz_ID_SERV_CT_MISS[128];  // "The Service Control Manager could not be contacted - the UltraVNC Server service was not registered"
char sz_ID_SERV_OLD_REG[64];  //   "The UltraVNC Server service is already registered"
char sz_ID_SERVHELP_UNAB[128]; // "WARNING:Unable to install the ServiceHelper hook\nGlobal user-specific registry settings will not be loaded"
char sz_ID_SERV_CT_UNREG[128]; // "The Service Control Manager could not be contacted - the UltraVNC Server service was not unregistered"
char sz_ID_SERV_NOT_UNRG[64];  //  "The UltraVNC Server service could not be unregistered"
char sz_ID_SERV_NCONTACT[64];  //  "The UltraVNC Server service could not be contacted"
char sz_ID_SERVHELP_NREM[126]; // "WARNING:The ServiceHelper hook entry could not be removed from the registry"
char sz_ID_SERV_NOT_STOP[64];  //  "The UltraVNC Server service could not be stopped"
char sz_ID_SERV_MK_UNREG[64];  // "The UltraVNC Server service is already marked to be unregistered"
char sz_ID_SERV_NT_FOUND[64];
char sz_ID_WINVNC_ERROR[64];
char sz_ID_WINVNC_WARNIN[64];  //  "UltraVNC Server - Warning"
char sz_ID_PLUGIN_LOADIN[64];  //  "Plugin Loading"
char sz_ID_NO_PASSWD_NO_OVERRIDE_ERR[200];
char sz_ID_NO_PASSWD_NO_OVERRIDE_WARN[160];
char sz_ID_NO_PASSWD_NO_LOGON_WARN [140]; // "WARNING : This machine has no default password set. UltraVNC Server will present the Default Properties dialog now to allow one to be entered.";
char sz_ID_NO_OVERRIDE_ERR [200];
char sz_ID_NO_CURRENT_USER_ERR [128]; // = "The UltraVNC Server settings for the current user are unavailable at present.";
char sz_ID_CANNOT_EDIT_DEFAULT_PREFS [128]; // = "You do not have sufficient priviliges to edit the default local UltraVNC Server settings.";
char sz_ID_NO_PASSWORD_WARN [200]; 
char sz_ID_PLUGIN_NOT_LOAD [200]; //  "The Plugin cannot be loaded.\n\rPlease check its integrity.";
char sz_ID_MB1 [10]; //  "MB1";
char sz_ID_WVNC [10]; //  "WVNC";
char sz_ID_AUTHAD_NOT_FO [128]; //  "You selected MS-Logon, but the authad.dll\nwas not found.Check you installation"
char sz_ID_WARNING [64] ; //  "WARNING";
char sz_ID_AUTH_NOT_FO [128]; //    "You selected MS-Logon, but the auth.dll\nwas not found.Check you installation";
char sz_ID_DESKTOP_BITBLT_ROOT [128]; //   "vncDesktop : root device doesn't support BitBlt\n"       "UltraVNC Server cannot be used with this graphics device driver";
char sz_ID_DESKTOP_BITBLT_MEM [128];  //   "vncDesktop : memory device doesn't support GetDIBits\n"  "UltraVNC Server cannot be used with this graphics device driver";
char sz_ID_DESKTOP_PLANAR_NOTC [128]; //   "vncDesktop : current display is PLANAR, not CHUNKY!\n"   "UltraVNC Server cannot be used with this graphics device driver";
char sz_ID_FAILED_CONNECT_LISTING_VIEW [64]; //  "Failed to connect to listening VNC Viewer";
char sz_ID_OUTGOING_CONNECTION [64] ; //  "Outgoing Connection";
char sz_ID_UNABLE_PROC_MSLOGON [64]; //  "Unable to process MS-Logon";
char sz_ID_RICHED32_UNLOAD [64]; //  "Unable to load the Rich Edit (RICHED32.DLL) control!";
char sz_ID_RICHED32_DLL_LD [64]; //  "Rich Edit Dll Loading";
char sz_ID_SERV_SUCCESS_INST[200];
char sz_ID_SERV_SUCCESS_REG[200];
char sz_ID_SERV_SUCCESS_UNREG[64]; //    "The UltraVNC Server service has been unregistered";
char sz_ID_ULTRAVNC_TEXTCHAT[128]; // "The selected client is not an UltraVNC Viewer!\n" "It presumably does not support Text Chat\n";
char sz_ID_ULTRAVNC_WARNING [64]; //     "UltraVNC Warning";
char sz_ID_NO_PLUGIN_DETECT [64]; // "No Plugin detected..."

char sz_ID_CHAT_WITH_S_ULTRAVNC [64]; //   "UltraVNC Server - Chat with <%s>"
char sz_ID_CURRENT_USER_PROP [64]; //   "UltraVNC Server: Current User Properties"
char sz_ID_DEFAULT_SYST_PROP [64]; //  "UltraVNC Server: Default Local System Properties"
char sz_ID_AUTOREJECT_U [64] ; //  "AutoReject:%u"
char sz_ID_AUTOACCEPT_U [64] ; //  "AutoAccept:%u"
char sz_ID_CADERROR [128];
char sz_ID_CADERRORFILE [128];
char sz_ID_CADPERMISSION [128];

// New string definitions for hardcoded MessageBoxSecure strings
char sz_ID_WINDOWS_XP_SPECIAL_BUILD[64];
char sz_ID_WARNING_CAPTION[64];
char sz_ID_ERROR_OS_NOT_SUPPORTED[64];
char sz_ID_UNSUPPORTED_OS_CAPTION[64];
char sz_ID_AUTHADMIN_DLL_NOT_FOUND[64];
char sz_ID_WORKGRPDOMNT4_DLL_NOT_FOUND[64];
char sz_ID_LDAPAUTH_DLL_NOT_FOUND[64];
char sz_ID_LDAPAUTHNT4_DLL_NOT_FOUND[64];
char sz_ID_LDAPAUTH9X_DLL_NOT_FOUND[64];
char sz_ID_KILL_VIEWERS_QUESTION[128];
char sz_ID_RESTART_SERVER_QUESTION[128];
char sz_ID_CLOSE_SERVER_QUESTION[128];
char sz_ID_REBOOT_SYSTEM_QUESTION[128];
char sz_ID_FORCE_REBOOT_QUESTION[128];
char sz_ID_UNINSTALL_SERVICE_QUESTION[128];
char sz_ID_INSTALL_SERVICE_QUESTION[128];
char sz_ID_STOP_SERVICE_QUESTION[128];
char sz_ID_START_SERVICE_QUESTION[128];
char sz_ID_SYSTEM_CAPTION[64];
char sz_ID_SERVICE_CAPTION[64];
char sz_ID_CURRENT_DRIVER_OLD[256];
char sz_ID_DRIVER_NOT_FOUND_REBOOT[128];
char sz_ID_DRIVER_INFO_REQUIRED_VERSION[128];
char sz_ID_FAILED_OPEN_SVC_MGR[128];
char sz_ID_FAILED_PERMISSION_DENIED[128];
char sz_ID_FAILED_CREATE_SVC[128];
char sz_ID_FAILED_SVC_NOT_INSTALLED[128];
char sz_ID_FAILED_OPEN_SVC[128];
char sz_ID_FAILED_QUERY_SVC_STATUS[128];
char sz_ID_FAILED_DELETE_SVC[128];
char sz_ID_WRONG_PASSWORD_RETRY[128];
char sz_ID_ERROR_CAPTION[64];
char sz_ID_UAC_DISABLED_REGISTRY[128];
char sz_ID_VERIFY_SAME_FOLDER[256];

// Driver message string definitions
char sz_ID_DRIVER_FOUND[64];
char sz_ID_DRIVER_VERSION_OK[64];
char sz_ID_DRIVER_VERSION_NOT_OK[64];
char sz_ID_DRIVER_NOT_ACTIVATED[128];
char sz_ID_DRIVER_ONLY_SERVICE_ADMIN[128];
char sz_ID_DRIVER_ACTIVE[64];
char sz_ID_DRIVER_ACCESS_OK[64];
char sz_ID_DRIVER_ACCESS_DENIED[64];


int Load_Localization(HINSTANCE hInstance) 
{

   LoadString(hInstance, ID_FAILED_INIT, sz_ID_FAILED_INIT, 64 -1); 
   LoadString(hInstance, ID_WINVNC_USAGE, sz_ID_WINVNC_USAGE, 64 -1); 
   LoadString(hInstance, ID_ANOTHER_INST, sz_ID_ANOTHER_INST, 64 -1); 
   LoadString(hInstance, ID_NO_EXIST_INST, sz_ID_NO_EXIST_INST, 64 -1);
   LoadString(hInstance, ID_UNABLE_INST, sz_ID_UNABLE_INST, 64 -1); 
   LoadString(hInstance, ID_SCM_NOT_HERE, sz_ID_SCM_NOT_HERE, 128 -1); 
   LoadString(hInstance, ID_SERV_NOT_REG, sz_ID_SERV_NOT_REG, 64 -1); 
   LoadString(hInstance, ID_SERV_FAIL_ST, sz_ID_SERV_FAIL_ST, 64 -1); 
   LoadString(hInstance, ID_SERV_CT_MISS, sz_ID_SERV_CT_MISS, 128 -1); 
   LoadString(hInstance, ID_SERV_OLD_REG, sz_ID_SERV_OLD_REG, 64 -1); 
   LoadString(hInstance, ID_SERVHELP_UNAB, sz_ID_SERVHELP_UNAB, 128 -1); 
   LoadString(hInstance, ID_SERV_CT_UNREG, sz_ID_SERV_CT_UNREG, 128 -1); 
   LoadString(hInstance, ID_SERV_NOT_UNRG, sz_ID_SERV_NOT_UNRG, 64 -1);  
   LoadString(hInstance, ID_SERV_NCONTACT, sz_ID_SERV_NCONTACT, 64 -1); 
   LoadString(hInstance, ID_SERVHELP_NREM, sz_ID_SERVHELP_NREM, 126 -1); 
   LoadString(hInstance, ID_SERV_NOT_STOP, sz_ID_SERV_NOT_STOP, 64 -1);  
   LoadString(hInstance, ID_SERV_MK_UNREG, sz_ID_SERV_MK_UNREG, 64 -1); 
   LoadString(hInstance, ID_SERV_NT_FOUND, sz_ID_SERV_NT_FOUND, 64 -1);
   LoadString(hInstance, ID_WINVNC_ERROR, sz_ID_WINVNC_ERROR, 64 -1);
   LoadString(hInstance, ID_WINVNC_WARNIN, sz_ID_WINVNC_WARNIN, 64 -1); 
   LoadString(hInstance, ID_PLUGIN_LOADIN, sz_ID_PLUGIN_LOADIN, 64 -1); 
   LoadString(hInstance, ID_NO_PASSWD_NO_OVERRIDE_ERR, sz_ID_NO_PASSWD_NO_OVERRIDE_ERR, 200 -1);
   LoadString(hInstance, ID_NO_PASSWD_NO_OVERRIDE_WARN, sz_ID_NO_PASSWD_NO_OVERRIDE_WARN, 160 -1);
   LoadString(hInstance, ID_NO_PASSWD_NO_LOGON_WARN, sz_ID_NO_PASSWD_NO_LOGON_WARN , 140 -1); 
   LoadString(hInstance, ID_NO_OVERRIDE_ERR, sz_ID_NO_OVERRIDE_ERR , 200 -1);
   LoadString(hInstance, ID_NO_CURRENT_USER_ERR, sz_ID_NO_CURRENT_USER_ERR , 128 -1);
   LoadString(hInstance, ID_CANNOT_EDIT_DEFAULT_PREFS, sz_ID_CANNOT_EDIT_DEFAULT_PREFS , 128 -1); 
   LoadString(hInstance, ID_NO_PASSWORD_WARN, sz_ID_NO_PASSWORD_WARN , 200 -1); 
   LoadString(hInstance, ID_PLUGIN_NOT_LOAD, sz_ID_PLUGIN_NOT_LOAD , 200 -1);
   LoadString(hInstance, ID_MB1, sz_ID_MB1 , 10 -1); 
   LoadString(hInstance, ID_WVNC, sz_ID_WVNC , 10 -1); 
   LoadString(hInstance, ID_AUTHAD_NOT_FO, sz_ID_AUTHAD_NOT_FO , 128 -1); 
   LoadString(hInstance, ID_WARNING, sz_ID_WARNING , 64 -1) ; 
   LoadString(hInstance, ID_AUTH_NOT_FO, sz_ID_AUTH_NOT_FO , 128 -1);
   LoadString(hInstance, ID_DESKTOP_BITBLT_ROOT, sz_ID_DESKTOP_BITBLT_ROOT , 128 -1);
   LoadString(hInstance, ID_DESKTOP_BITBLT_MEM, sz_ID_DESKTOP_BITBLT_MEM , 128 -1);
   LoadString(hInstance, ID_DESKTOP_PLANAR_NOTC, sz_ID_DESKTOP_PLANAR_NOTC , 128 -1); 
   LoadString(hInstance, ID_FAILED_CONNECT_LISTING_VIEW, sz_ID_FAILED_CONNECT_LISTING_VIEW , 64 -1);
   LoadString(hInstance, ID_OUTGOING_CONNECTION, sz_ID_OUTGOING_CONNECTION , 64 -1); 
   LoadString(hInstance, ID_UNABLE_PROC_MSLOGON, sz_ID_UNABLE_PROC_MSLOGON , 64 -1);
   LoadString(hInstance, ID_RICHED32_UNLOAD, sz_ID_RICHED32_UNLOAD , 64 -1); 
   LoadString(hInstance, ID_RICHED32_DLL_LD, sz_ID_RICHED32_DLL_LD , 64 -1); 
   LoadString(hInstance, ID_SERV_SUCCESS_INST, sz_ID_SERV_SUCCESS_INST, 200 -1);
   LoadString(hInstance, ID_SERV_SUCCESS_REG, sz_ID_SERV_SUCCESS_REG, 200 -1);
   LoadString(hInstance, ID_SERV_SUCCESS_UNREG, sz_ID_SERV_SUCCESS_UNREG, 64 -1); 
   LoadString(hInstance, ID_ULTRAVNC_TEXTCHAT, sz_ID_ULTRAVNC_TEXTCHAT, 128 -1); 
   LoadString(hInstance, ID_ULTRAVNC_WARNING, sz_ID_ULTRAVNC_WARNING , 64 -1); 
   LoadString(hInstance, ID_NO_PLUGIN_DETECT, sz_ID_NO_PLUGIN_DETECT , 64 -1); 
   LoadString(hInstance, ID_CHAT_WITH_S_ULTRAVNC, sz_ID_CHAT_WITH_S_ULTRAVNC, 64 -1);
   LoadString(hInstance, ID_CURRENT_USER_PROP, sz_ID_CURRENT_USER_PROP, 64 -1); 
   LoadString(hInstance, ID_DEFAULT_SYST_PROP, sz_ID_DEFAULT_SYST_PROP, 64 -1); 
   LoadString(hInstance, ID_AUTOREJECT_U, sz_ID_AUTOREJECT_U, 64 -1);
   LoadString(hInstance, ID_AUTOACCEPT_U, sz_ID_AUTOACCEPT_U, 64 -1);
   LoadString(hInstance, ID_CADERROR, sz_ID_CADERROR , 128 -1);
   LoadString(hInstance, ID_CADERROR, sz_ID_CADERRORFILE , 128 -1);
   LoadString(hInstance, ID_CADERROR, sz_ID_CADPERMISSION , 128 -1);

   // LoadString calls for new hardcoded strings
   LoadString(hInstance, IDS_WINDOWS_XP_SPECIAL_BUILD, sz_ID_WINDOWS_XP_SPECIAL_BUILD, 64 -1);
   LoadString(hInstance, IDS_WARNING_CAPTION, sz_ID_WARNING_CAPTION, 64 -1);
   LoadString(hInstance, IDS_ERROR_OS_NOT_SUPPORTED, sz_ID_ERROR_OS_NOT_SUPPORTED, 64 -1);
   LoadString(hInstance, IDS_UNSUPPORTED_OS_CAPTION, sz_ID_UNSUPPORTED_OS_CAPTION, 64 -1);
   LoadString(hInstance, IDS_AUTHADMIN_DLL_NOT_FOUND, sz_ID_AUTHADMIN_DLL_NOT_FOUND, 64 -1);
   LoadString(hInstance, IDS_WORKGRPDOMNT4_DLL_NOT_FOUND, sz_ID_WORKGRPDOMNT4_DLL_NOT_FOUND, 64 -1);
   LoadString(hInstance, IDS_LDAPAUTH_DLL_NOT_FOUND, sz_ID_LDAPAUTH_DLL_NOT_FOUND, 64 -1);
   LoadString(hInstance, IDS_LDAPAUTHNT4_DLL_NOT_FOUND, sz_ID_LDAPAUTHNT4_DLL_NOT_FOUND, 64 -1);
   LoadString(hInstance, IDS_LDAPAUTH9X_DLL_NOT_FOUND, sz_ID_LDAPAUTH9X_DLL_NOT_FOUND, 64 -1);
   LoadString(hInstance, IDS_KILL_VIEWERS_QUESTION, sz_ID_KILL_VIEWERS_QUESTION, 128 -1);
   LoadString(hInstance, IDS_RESTART_SERVER_QUESTION, sz_ID_RESTART_SERVER_QUESTION, 128 -1);
   LoadString(hInstance, IDS_CLOSE_SERVER_QUESTION, sz_ID_CLOSE_SERVER_QUESTION, 128 -1);
   LoadString(hInstance, IDS_REBOOT_SYSTEM_QUESTION, sz_ID_REBOOT_SYSTEM_QUESTION, 128 -1);
   LoadString(hInstance, IDS_FORCE_REBOOT_QUESTION, sz_ID_FORCE_REBOOT_QUESTION, 128 -1);
   LoadString(hInstance, IDS_UNINSTALL_SERVICE_QUESTION, sz_ID_UNINSTALL_SERVICE_QUESTION, 128 -1);
   LoadString(hInstance, IDS_INSTALL_SERVICE_QUESTION, sz_ID_INSTALL_SERVICE_QUESTION, 128 -1);
   LoadString(hInstance, IDS_STOP_SERVICE_QUESTION, sz_ID_STOP_SERVICE_QUESTION, 128 -1);
   LoadString(hInstance, IDS_START_SERVICE_QUESTION, sz_ID_START_SERVICE_QUESTION, 128 -1);
   LoadString(hInstance, IDS_SYSTEM_CAPTION, sz_ID_SYSTEM_CAPTION, 64 -1);
   LoadString(hInstance, IDS_SERVICE_CAPTION, sz_ID_SERVICE_CAPTION, 64 -1);
   LoadString(hInstance, IDS_CURRENT_DRIVER_OLD, sz_ID_CURRENT_DRIVER_OLD, 256 -1);
   LoadString(hInstance, IDS_DRIVER_NOT_FOUND_REBOOT, sz_ID_DRIVER_NOT_FOUND_REBOOT, 128 -1);
   LoadString(hInstance, IDS_DRIVER_INFO_REQUIRED_VERSION, sz_ID_DRIVER_INFO_REQUIRED_VERSION, 128 -1);
   LoadString(hInstance, IDS_FAILED_OPEN_SVC_MGR, sz_ID_FAILED_OPEN_SVC_MGR, 128 -1);
   LoadString(hInstance, IDS_FAILED_PERMISSION_DENIED, sz_ID_FAILED_PERMISSION_DENIED, 128 -1);
   LoadString(hInstance, IDS_FAILED_CREATE_SVC, sz_ID_FAILED_CREATE_SVC, 128 -1);
   LoadString(hInstance, IDS_FAILED_SVC_NOT_INSTALLED, sz_ID_FAILED_SVC_NOT_INSTALLED, 128 -1);
   LoadString(hInstance, IDS_FAILED_OPEN_SVC, sz_ID_FAILED_OPEN_SVC, 128 -1);
   LoadString(hInstance, IDS_FAILED_QUERY_SVC_STATUS, sz_ID_FAILED_QUERY_SVC_STATUS, 128 -1);
   LoadString(hInstance, IDS_FAILED_DELETE_SVC, sz_ID_FAILED_DELETE_SVC, 128 -1);
   LoadString(hInstance, IDS_WRONG_PASSWORD_RETRY, sz_ID_WRONG_PASSWORD_RETRY, 128 -1);
   LoadString(hInstance, IDS_ERROR_CAPTION, sz_ID_ERROR_CAPTION, 64 -1);
   LoadString(hInstance, IDS_UAC_DISABLED_REGISTRY, sz_ID_UAC_DISABLED_REGISTRY, 128 -1);
   LoadString(hInstance, IDS_VERIFY_SAME_FOLDER, sz_ID_VERIFY_SAME_FOLDER, 256 -1);

   // LoadString calls for driver messages
   LoadString(hInstance, IDS_DRIVER_FOUND, sz_ID_DRIVER_FOUND, 64 -1);
   LoadString(hInstance, IDS_DRIVER_VERSION_OK, sz_ID_DRIVER_VERSION_OK, 64 -1);
   LoadString(hInstance, IDS_DRIVER_VERSION_NOT_OK, sz_ID_DRIVER_VERSION_NOT_OK, 64 -1);
   LoadString(hInstance, IDS_DRIVER_NOT_ACTIVATED, sz_ID_DRIVER_NOT_ACTIVATED, 128 -1);
   LoadString(hInstance, IDS_DRIVER_ONLY_SERVICE_ADMIN, sz_ID_DRIVER_ONLY_SERVICE_ADMIN, 128 -1);
   LoadString(hInstance, IDS_DRIVER_ACTIVE, sz_ID_DRIVER_ACTIVE, 64 -1);
   LoadString(hInstance, IDS_DRIVER_ACCESS_OK, sz_ID_DRIVER_ACCESS_OK, 64 -1);
   LoadString(hInstance, IDS_DRIVER_ACCESS_DENIED, sz_ID_DRIVER_ACCESS_DENIED, 64 -1);


  return 0;
}

#else

extern char sz_ID_FAILED_INIT[64];  //    "Failed to initialise the socket system"
extern char sz_ID_WINVNC_USAGE[64];  //   "UltraVNC Server Usage"
extern char sz_ID_ANOTHER_INST[64];  //   "Another instance of UltraVNC Server is already running"
extern char sz_ID_NO_EXIST_INST[64];  // "No existing instance of UltraVNC Server could be contacted"
extern char sz_ID_UNABLE_INST[64];  //    "Unable to install UltraVNC Server service"
extern char sz_ID_SCM_NOT_HERE[128];  // "The SCM could not be contacted - the UltraVNC Server service was not installed"
extern char sz_ID_SERV_NOT_REG[64];   // "The UltraVNC Server service could not be registered"
extern char sz_ID_SERV_FAIL_ST[64];  //   "The UltraVNC Server service failed to start"
extern char sz_ID_SERV_CT_MISS[128];  // "The Service Control Manager could not be contacted - the UltraVNC Server service was not registered"
extern char sz_ID_SERV_OLD_REG[64];  //   "The UltraVNC Server service is already registered"
extern char sz_ID_SERVHELP_UNAB[128]; // "WARNING:Unable to install the ServiceHelper hook\nGlobal user-specific registry settings will not be loaded"
extern char sz_ID_SERV_CT_UNREG[128]; // "The Service Control Manager could not be contacted - the UltraVNC Server service was not unregistered"
extern char sz_ID_SERV_NOT_UNRG[64];  //  "The UltraVNC Server service could not be unregistered"
extern char sz_ID_SERV_NCONTACT[64];  //  "The UltraVNC Server service could not be contacted"
extern char sz_ID_SERVHELP_NREM[126]; // "WARNING:The ServiceHelper hook entry could not be removed from the registry"
extern char sz_ID_SERV_NOT_STOP[64];  //  "The UltraVNC Server service could not be stopped"
extern char sz_ID_SERV_MK_UNREG[64];  // "The UltraVNC Server service is already marked to be unregistered"
extern char sz_ID_SERV_NT_FOUND[64];
extern char sz_ID_WINVNC_ERROR[64];
extern char sz_ID_WINVNC_WARNIN[64];  //  "UltraVNC Server - Warning"
extern char sz_ID_PLUGIN_LOADIN[64];  //  "Plugin Loading"
extern char sz_ID_NO_PASSWD_NO_OVERRIDE_ERR[200];
extern char sz_ID_NO_PASSWD_NO_OVERRIDE_WARN[160];
extern char sz_ID_NO_PASSWD_NO_LOGON_WARN [140]; // "WARNING : This machine has no default password set. UltraVNC Server will present the Default Properties dialog now to allow one to be entered.";
extern char sz_ID_NO_OVERRIDE_ERR [200];
extern char sz_ID_NO_CURRENT_USER_ERR [128]; // = "The UltraVNC Server settings for the current user are unavailable at present.";
extern char sz_ID_CANNOT_EDIT_DEFAULT_PREFS [128]; // = "You do not have sufficient priviliges to edit the default local UltraVNC Server settings.";
extern char sz_ID_NO_PASSWORD_WARN [200]; 
extern char sz_ID_PLUGIN_NOT_LOAD [200]; //  "The Plugin cannot be loaded.\n\rPlease check its integrity.";
extern char sz_ID_MB1 [10]; //  "MB1";
extern char sz_ID_WVNC [10]; //  "WVNC";
extern char sz_ID_AUTHAD_NOT_FO [128]; //  "You selected MS-Logon, but the authad.dll\nwas not found.Check you installation"
extern char sz_ID_WARNING [64] ; //  "WARNING";
extern char sz_ID_AUTH_NOT_FO [128]; //    "You selected MS-Logon, but the auth.dll\nwas not found.Check you installation";
extern char sz_ID_DESKTOP_BITBLT_ROOT [128]; //   "vncDesktop : root device doesn't support BitBlt\n"       "UltraVNC Server cannot be used with this graphics device driver";
extern char sz_ID_DESKTOP_BITBLT_MEM [128];  //   "vncDesktop : memory device doesn't support GetDIBits\n"  "UltraVNC Server cannot be used with this graphics device driver";
extern char sz_ID_DESKTOP_PLANAR_NOTC [128]; //   "vncDesktop : current display is PLANAR, not CHUNKY!\n"   "UltraVNC Server cannot be used with this graphics device driver";
extern char sz_ID_FAILED_CONNECT_LISTING_VIEW [64]; //  "Failed to connect to listening VNC Viewer";
extern char sz_ID_OUTGOING_CONNECTION [64] ; //  "Outgoing Connection";
extern char sz_ID_UNABLE_PROC_MSLOGON [64]; //  "Unable to process MS-Logon";
extern char sz_ID_RICHED32_UNLOAD [64]; //  "Unable to load the Rich Edit (RICHED32.DLL) control!";
extern char sz_ID_RICHED32_DLL_LD [64]; //  "Rich Edit Dll Loading";
extern char sz_ID_SERV_SUCCESS_INST[200];
extern char sz_ID_SERV_SUCCESS_REG[200];
extern char sz_ID_SERV_SUCCESS_UNREG[64]; //    "The UltraVNC Server service has been unregistered";
extern char sz_ID_ULTRAVNC_TEXTCHAT[128]; // "The selected client is not an UltraVNC Viewer!\n" "It presumably does not support Text Chat\n";
extern char sz_ID_ULTRAVNC_WARNING [64]; //     "UltraVNC Warning";

extern char sz_ID_NO_PLUGIN_DETECT [64]; // "No Plugin detected..."

extern char sz_ID_CHAT_WITH_S_ULTRAVNC [64]; //   "UltraVNC Server - Chat with <%s>"
extern char sz_ID_CURRENT_USER_PROP [64]; //   "UltraVNC Server: Current User Properties"
extern char sz_ID_DEFAULT_SYST_PROP [64]; //  "UltraVNC Server: Default Local System Properties"
extern char sz_ID_AUTOREJECT_U [64] ; //  "AutoReject:%u"
extern char sz_ID_AUTOACCEPT_U [64] ; //  "AutoReject:%u"
extern char sz_ID_CADERROR [128];
extern char sz_ID_CADERRORFILE [128];
extern char sz_ID_CADPERMISSION [128];

// New string declarations for hardcoded MessageBoxSecure strings
extern char sz_ID_WINDOWS_XP_SPECIAL_BUILD[64];
extern char sz_ID_WARNING_CAPTION[64];
extern char sz_ID_ERROR_OS_NOT_SUPPORTED[64];
extern char sz_ID_UNSUPPORTED_OS_CAPTION[64];
extern char sz_ID_AUTHADMIN_DLL_NOT_FOUND[64];
extern char sz_ID_WORKGRPDOMNT4_DLL_NOT_FOUND[64];
extern char sz_ID_LDAPAUTH_DLL_NOT_FOUND[64];
extern char sz_ID_LDAPAUTHNT4_DLL_NOT_FOUND[64];
extern char sz_ID_LDAPAUTH9X_DLL_NOT_FOUND[64];
extern char sz_ID_KILL_VIEWERS_QUESTION[128];
extern char sz_ID_RESTART_SERVER_QUESTION[128];
extern char sz_ID_CLOSE_SERVER_QUESTION[128];
extern char sz_ID_REBOOT_SYSTEM_QUESTION[128];
extern char sz_ID_FORCE_REBOOT_QUESTION[128];
extern char sz_ID_UNINSTALL_SERVICE_QUESTION[128];
extern char sz_ID_INSTALL_SERVICE_QUESTION[128];
extern char sz_ID_STOP_SERVICE_QUESTION[128];
extern char sz_ID_START_SERVICE_QUESTION[128];
extern char sz_ID_SYSTEM_CAPTION[64];
extern char sz_ID_SERVICE_CAPTION[64];
extern char sz_ID_CURRENT_DRIVER_OLD[256];
extern char sz_ID_DRIVER_NOT_FOUND_REBOOT[128];
extern char sz_ID_DRIVER_INFO_REQUIRED_VERSION[128];
extern char sz_ID_FAILED_OPEN_SVC_MGR[128];
extern char sz_ID_FAILED_PERMISSION_DENIED[128];
extern char sz_ID_FAILED_CREATE_SVC[128];
extern char sz_ID_FAILED_SVC_NOT_INSTALLED[128];
extern char sz_ID_FAILED_OPEN_SVC[128];
extern char sz_ID_FAILED_QUERY_SVC_STATUS[128];
extern char sz_ID_FAILED_DELETE_SVC[128];
extern char sz_ID_WRONG_PASSWORD_RETRY[128];
extern char sz_ID_ERROR_CAPTION[64];
extern char sz_ID_UAC_DISABLED_REGISTRY[128];
extern char sz_ID_VERIFY_SAME_FOLDER[256];

// Driver message string declarations
extern char sz_ID_DRIVER_FOUND[64];
extern char sz_ID_DRIVER_VERSION_OK[64];
extern char sz_ID_DRIVER_VERSION_NOT_OK[64];
extern char sz_ID_DRIVER_NOT_ACTIVATED[128];
extern char sz_ID_DRIVER_ONLY_SERVICE_ADMIN[128];
extern char sz_ID_DRIVER_ACTIVE[64];
extern char sz_ID_DRIVER_ACCESS_OK[64];
extern char sz_ID_DRIVER_ACCESS_DENIED[64];

// Function to reload localization strings
extern int Load_Localization(HINSTANCE hInstance);

#endif
