// This file is part of UltraVNC
// https://github.com/ultravnc/UltraVNC
// https://uvnc.com/
//
// SPDX-License-Identifier: GPL-3.0-or-later
//
// SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 2004 Martin Scharpf. All Rights Reserved.

#pragma warning(disable: 4996)

// /macine-vnc Greg Wood (wood@agressiv.com)


//#include "../../winvnc/stdhdrs.h"
#include <objbase.h> // for CoInitialize/CoUninitialize ???
#include <time.h>
#include "vncSSP.h"
// From vncAccessControl.h
#define ViewOnly 0x0001
#define Interact 0x0002

#include "../../../winvnc/winvnc/localization.h" // Act : add localization on messages

CheckUserPasswordSDFn CheckUserPasswordSD = 0;

const TCHAR REGISTRY_KEY [] = _T("Software\\UltraVNC");

AUTHSSP_API
int CUPSD(const char* userin, const char* password, const char* machine)
{
	DWORD dwAccessGranted = 0;
	BOOL isAccessOK = FALSE;
	BOOL NT4OS = FALSE;
	BOOL W2KOS = FALSE;
	BOOL isAuthenticated = FALSE;
	bool isViewOnly = false;
	bool isInteract = false;
	TCHAR machine2[MAXSTRING];
	TCHAR user2[MAXSTRING];
#if defined(UNICODE) || defined(_UNICODE)
	size_t pnconv;
	mbstowcs_s(&pnconv, machine2, MAXSTRING, machine, MAXSTRING);
	mbstowcs_s(&pnconv, user2, MAXSTRING, userin, MAXSTRING);
#else
	strcpy(machine2, machine);
	strcpy(user2, userin);
#endif

	OSVERSIONINFO VerInfo;
	VerInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if (!GetVersionEx(&VerInfo)) {  // If this fails, something has gone wrong
		return FALSE;
	}

	if (VerInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) { // Windows NT 3.51 or better 
		vncAccessControl vncAC;
		isAccessOK = CUPSD2(userin, password, vncAC.GetSD(), &isAuthenticated, &dwAccessGranted);
		// This logging should be moved to LOGLOGONUSER etc.
		FILE* file = fopen("WinVNC-authSSP.log", "a");
		if (file) {
			time_t current;
			time(&current);
			char timestr[50];
			ctime_s(timestr, 50, &current);
			timestr[49] = '\0'; // remove newline
			fprintf(file, "%s - CUPSD2: Access is %u, user %s is %sauthenticated, access granted is 0x%x\n",
				timestr, isAccessOK, userin, isAuthenticated ? "" : "not ", dwAccessGranted);
			fclose(file);
		}
	}
	else { // message text to be moved to localization.h
		MessageBox(NULL, _T("New MS-Logon currently not supported on Win9x"), _T("Warning"), MB_OK);
		return FALSE;
	}

	if (isAccessOK) {
		if (dwAccessGranted & ViewOnly) isViewOnly = true;
		if (dwAccessGranted & Interact) isInteract = true;
	}

	//LookupAccountName(NULL, user2, Sid, cbSid, DomainName, cbDomainName, peUse);

	if (isInteract) {
		LOG(0x00640001L, _T("MS-Logon authentication accepted from %s using %s account (Interactive)\n"), machine2, user2);
	}
	else if (isViewOnly) {
		LOG(0x00640001L, _T("MS-Logon authentication accepted from %s using %s account (ViewOnly)\n"), machine2, user2);		isAccessOK = 2;
	}
	else {
		LOG(0x00640002L, _T("MS-Logon authentication refused from %s using %s account (not %s)\n"), machine2, user2,
			isAuthenticated ? _T("authorized") : _T("authenticated"));
	}
	return isAccessOK;
}

AUTHSSP_API
int CUPSDV2(const char * userin, const char *password, const char *machine, TCHAR* szMslogonLog)
{
	DWORD dwAccessGranted = 0;
	BOOL isAccessOK = FALSE;
	BOOL NT4OS=FALSE;
	BOOL W2KOS=FALSE;
	BOOL isAuthenticated = FALSE;
	bool isViewOnly = false;
	bool isInteract = false;
	TCHAR machine2[MAXSTRING];
	TCHAR user2[MAXSTRING];
#if defined(UNICODE) || defined(_UNICODE)
	size_t pnconv;
	mbstowcs_s(&pnconv, machine2, MAXSTRING, machine, MAXSTRING);
	mbstowcs_s(&pnconv, user2, MAXSTRING, userin, MAXSTRING);
#else
	strcpy(machine2, machine);
	strcpy(user2, userin);
#endif

	OSVERSIONINFO VerInfo;
	VerInfo.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
	if (!GetVersionEx (&VerInfo)) {  // If this fails, something has gone wrong
		return FALSE;
	}
	
	if (VerInfo.dwPlatformId == VER_PLATFORM_WIN32_NT) { // Windows NT 3.51 or better 
		vncAccessControl vncAC;
		isAccessOK = CUPSD2(userin, password, vncAC.GetSD(), &isAuthenticated, &dwAccessGranted);
		// This logging should be moved to LOGLOGONUSER etc.
		FILE *file = fopen("WinVNC-authSSP.log", "a");
		if (file) {
            time_t current;
			time(&current);
			char timestr[50];
			ctime_s(timestr, 50, &current);
			timestr[49] = '\0'; // remove newline
			fprintf(file, "%s - CUPSD2: Access is %u, user %s is %sauthenticated, access granted is 0x%x\n",
				timestr, isAccessOK, userin, isAuthenticated ? "" : "not ", dwAccessGranted);
			fclose(file);
		}
	} else { // message text to be moved to localization.h
		MessageBox(NULL, _T("New MS-Logon currently not supported on Win9x"), _T("Warning"), MB_OK);
		return FALSE;
	}

	if (isAccessOK) {
		if (dwAccessGranted & ViewOnly) isViewOnly = true;
		if (dwAccessGranted & Interact) isInteract = true;
	}
	
	//LookupAccountName(NULL, user2, Sid, cbSid, DomainName, cbDomainName, peUse);

	if (isInteract)	{
		LOGV2(szMslogonLog, 0x00640001L, _T("MS-Logon authentication accepted from %s using %s account (Interactive)\n"), machine2, user2);
	} else if (isViewOnly) {
		LOGV2(szMslogonLog, 0x00640001L, _T("MS-Logon authentication accepted from %s using %s account (ViewOnly)\n"), machine2, user2);
		isAccessOK = 2;
	} else {
		LOGV2(szMslogonLog, 0x00640002L, _T("MS-Logon authentication refused from %s using %s account (not %s)\n"), machine2, user2,
			isAuthenticated ? _T("authorized") : _T("authenticated"));
	}
	return isAccessOK;
}
	

TCHAR *AddToModuleDir(TCHAR *filename, int length){
	TCHAR *szCurrentDir = new TCHAR[length];
	if (GetModuleFileName(NULL, szCurrentDir, length))
	{
		TCHAR *p = _tcsrchr(szCurrentDir, '\\');
		*p = '\0';
		_tcscat_s(szCurrentDir, length, _T("\\"));
		_tcscat_s(szCurrentDir, length, filename);
	}
	filename = szCurrentDir;
	return filename;
}