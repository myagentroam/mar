// This file is part of UltraVNC
// https://github.com/ultravnc/UltraVNC
// https://uvnc.com/
//
// SPDX-License-Identifier: GPL-3.0-or-later
//
// SPDX-FileCopyrightText: Copyright (C) 2002-2025 UltraVNC Team Members. All Rights Reserved.
// SPDX-FileCopyrightText: Copyright (C) 1999-2002 Vdacc-VNC & eSVNC Projects. All Rights Reserved.
//


#include "stdafx.h"
#include "inifile.h"
#include <shlobj.h>
#include <direct.h>
#include <errno.h>

IniFile::IniFile()
{
	char programdataPath[MAX_PATH]{};
	char programdataFolder[MAX_PATH]{};
	if (SHGetFolderPathA(NULL, CSIDL_COMMON_APPDATA, NULL, 0, programdataPath) != S_OK)
		return;
	strcpy_s(programdataFolder, programdataPath);
	strcat_s(programdataFolder, "\\UltraVNC");
	// Create directory if it doesn't exist
	if (_mkdir(programdataFolder) != 0 && errno != EEXIST) {
		// Failed to create directory, fall back to exe folder
		char WORKDIR[MAX_PATH];
		if (GetModuleFileName(NULL, WORKDIR, MAX_PATH)) {
			char* p = strrchr(WORKDIR, '\\');
			if (p != NULL) *p = '\0';
		}
		strcpy_s(myInifile, WORKDIR);
		strcat_s(myInifile, "\\");
		strcat_s(myInifile, INIFILE_NAME);
		return;
	}
	strcpy_s(myInifile, programdataFolder);
	strcat_s(myInifile, "\\");
	strcat_s(myInifile, INIFILE_NAME);
}

void
IniFile::IniFileSetSecure()
{
	char programdataPath[MAX_PATH]{};
	char programdataFolder[MAX_PATH]{};
	if (SHGetFolderPathA(NULL, CSIDL_COMMON_APPDATA, NULL, 0, programdataPath) != S_OK)
		return;
	strcpy_s(programdataFolder, programdataPath);
	strcat_s(programdataFolder, "\\UltraVNC");
	if (_mkdir(programdataFolder) != 0 && errno != EEXIST)
		return;
	strcpy_s(myInifile, programdataFolder);
	strcat_s(myInifile, "\\");
	strcat_s(myInifile, INIFILE_NAME);
}

void
IniFile::IniFileSetTemp(char *lpCmdLine)
{
	strcpy_s(myInifile,lpCmdLine);
}

IniFile::~IniFile()
{
}

bool
IniFile::WriteString(char *key1, char *key2,char *value)
{
	//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifile);
	return (FALSE != WritePrivateProfileString(key1,key2, value,myInifile));
}

bool
IniFile::WriteInt(char *key1, char *key2,int value)
{
	char       buf[32];
	wsprintf(buf, "%d", value);
	//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifile);
	int result=WritePrivateProfileString(key1,key2, buf,myInifile);
	if (result==0) return false;
	return true;
}

int
IniFile::ReadInt(char *key1, char *key2,int Defaultvalue)
{
	//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifile);
	return GetPrivateProfileInt(key1, key2, Defaultvalue, myInifile);
}

void
IniFile::ReadString(char *key1, char *key2,char *value,int valuesize)
{
	//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifile);
	GetPrivateProfileString(key1,key2, "",value,valuesize,myInifile);
}

bool
IniFile::ReadPassword(char *value,int valuesize)
{
	//int size=ReadInt("UltraVNC", "passwdsize",0);
	//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifilePasswd);
	return GetPrivateProfileStruct("UltraVNC","passwd",value,8,myInifile);
}

bool
IniFile::WritePassword(char *value)
{
		//WriteInt("UltraVNC", "passwdsize",sizeof(value));
		//vnclog.Print(LL_INTERR, VNCLOG("%s \n"),myInifile);
		return (FALSE != WritePrivateProfileStruct("UltraVNC","passwd", value,8,myInifile));
}

bool//PGM
IniFile::ReadPassword2(char *value,int valuesize) //PGM
{ //PGM
	return GetPrivateProfileStruct("UltraVNC","passwd2",value,8,myInifile); //PGM
} //PGM

bool //PGM
IniFile::WritePassword2(char *value) //PGM
{ //PGM
		return (FALSE != WritePrivateProfileStruct("UltraVNC","passwd2", value,8,myInifile)); //PGM
} //PGM

bool IniFile::IsWritable()
{
    bool writable = WriteInt((char*)"Permissions", (char*)"isWritable",1);
    if (writable)
        WritePrivateProfileSection("Permissions", "", myInifile);

    return writable;
}