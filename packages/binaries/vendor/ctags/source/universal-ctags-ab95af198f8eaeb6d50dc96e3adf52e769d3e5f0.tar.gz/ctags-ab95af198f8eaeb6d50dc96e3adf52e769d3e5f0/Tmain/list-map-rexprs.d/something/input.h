double tdef;
